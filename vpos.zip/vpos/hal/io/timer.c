#include "vh_cpu_hal.h"
#include "vh_io_hal.h"
#include "timer.h"
#include "printk.h"
#include "dd.h"
#include "hwi_handler.h"
#include "scheduler.h"
#include "thread.h"
#include "queue.h"
#include "semaphore.h"
#include "recoplay.h"

extern int vk_sched_lock;
extern vk_thread_t *vk_current_thread;


void vk_timer_irq_enable(void)
{	
	vh_TCON &= ~(0x7000000);//1.bit 20 21 22 is timer 4 bit,2^20+2^21+2^22 =7340032,0x7000000
	vh_TCON |= 0x6000000;//2.bit 22 is AutoReload, 21 is Manual update,=6291456,0x6000000
	vh_TCON &= ~(0x7000000);//3.same as 1.
	vh_TCON |= 0x5000000;//4. bit 20 is start, start bit = 1, 2^20+2^22 = 5242880, 0x5000000
	vh_TINT_CSTAT |= 0x210;//5.Timer 4 interrupt status bit clear
}

void vk_timer_irq_disable(void)
{
	vh_TCON &= ~(0x7000000);//6. same as 1.
	vh_TCON |= 0x6000000; //7. same as 2.
	vh_TINT_CSTAT |= 0x210;//8. same as 5
}

void vh_timer_init(void)
{
	vk_timer_flag = 0;
	vh_TCFG0 = 0x00ff00;//timer4 prescaler 255
	vh_TCFG1 = 0x040000;//use 0100, 19:16-> 0100000000000000000=0x040000
	vh_TCNTB4 = 0x003ef1;//66MH/prescaler+1/diveder = 66000000/256/16=0x003ef1


}

void vh_timer_irq_enable(int timer)
{
	
	switch(timer){
	case 0: 
		 break;
	case 1: 
		 break;
	case 2:
		 break;
	case 3:	
		 break;
	case 4:
		 vh_VIC0VECTADDR25 = vh_timer_interrupt_handler;
		 vh_VIC0INTENABLE |= 0x2000000;// 2^25 = 0x2000000
		 vh_VIC0INTSELECT &= ~(0x2000000);//2^25 = 0x2000000
		 vh_VIC0SWPRIORITYMASK |= 0xffffffff;//all bit 1
		 break;
	default: break;
	}
}
void vh_timer_interrupt_handler(void)
{
	vk_timer_irq_disable();
	vh_save_thread_ctx(vk_timer_save_stk);
	
	// timer interrupt clear & enable
	
	vh_VIC0INTENCLEAR |= 0x2000000;//set bit 25 to 1, 2^25= 0x2000000
	vh_VIC0INTENABLE |= 0x2000000;//set bit 25 to 1, 2^25= 0x2000000
		
	vk_sched_save_tcb_ptr = (unsigned int)vk_timer_save_stk;
	vk_timer_flag = 1;

	++(vk_current_thread->cpu_tick);
	if(vk_sched_lock==0) {
		vk_swi_scheduler();
	}
}


#ifndef _VPOS_PRINTF_H_
#define _VPOS_PRINTF_H_

#include "printk.h"

#endif // _VPOS_PRINTF_H_
